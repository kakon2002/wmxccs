# wmxccs

Cross-platform CCS harmonization pipeline. Stores DTIMS, TWIMS, TIMS and cIMS
measurements without merging them, pairs the same ion across platforms, quantifies
inter-platform bias and agreement, and returns a harmonized CCS with uncertainty
and a confidence grade alongside the original values.

Separate from the glycan platform. See CLAUDE.md for constraints and CONTEXT.md
for everything already established, including which data sources are usable.

Deadline: deployable by 25 September 2026.
